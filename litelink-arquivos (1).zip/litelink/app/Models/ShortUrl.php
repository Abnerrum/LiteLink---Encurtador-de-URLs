<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShortUrl extends Model
{
    protected $fillable = [
        'original_url',
        'code',
        'clicks',
    ];

    protected $casts = [
        'clicks' => 'integer',
    ];
}
